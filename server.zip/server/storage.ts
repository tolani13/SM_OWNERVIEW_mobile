import { db } from "./db";
import { 
  dancers, insertDancerSchema, type InsertDancer, type Dancer,
  teachers, insertTeacherSchema, type InsertTeacher, type Teacher,
  routines, insertRoutineSchema, type InsertRoutine, type Routine,
  competitions, insertCompetitionSchema, type InsertCompetition, type Competition,
  runSlots, insertRunSlotSchema, type InsertRunSlot, type RunSlot,
  conventionClasses, insertConventionClassSchema, type InsertConventionClass, type ConventionClass,
  studioClasses, insertStudioClassSchema, type InsertStudioClass, type StudioClass,
  practiceBookings, insertPracticeBookingSchema, type InsertPracticeBooking, type PracticeBooking,
  announcements, insertAnnouncementSchema, type InsertAnnouncement, type Announcement,
  fees, insertFeeSchema, type InsertFee, type Fee
} from "@shared/schema";
import { eq } from "drizzle-orm";

export interface IStorage {
  // Dancers
  getDancers(): Promise<Dancer[]>;
  getDancer(id: string): Promise<Dancer | undefined>;
  createDancer(dancer: InsertDancer): Promise<Dancer>;
  updateDancer(id: string, dancer: Partial<InsertDancer>): Promise<Dancer | undefined>;
  deleteDancer(id: string): Promise<void>;

  // Teachers
  getTeachers(): Promise<Teacher[]>;
  getTeacher(id: string): Promise<Teacher | undefined>;
  createTeacher(teacher: InsertTeacher): Promise<Teacher>;
  updateTeacher(id: string, teacher: Partial<InsertTeacher>): Promise<Teacher | undefined>;
  deleteTeacher(id: string): Promise<void>;

  // Routines
  getRoutines(): Promise<Routine[]>;
  getRoutine(id: string): Promise<Routine | undefined>;
  createRoutine(routine: InsertRoutine): Promise<Routine>;
  updateRoutine(id: string, routine: Partial<InsertRoutine>): Promise<Routine | undefined>;
  deleteRoutine(id: string): Promise<void>;

  // Competitions
  getCompetitions(): Promise<Competition[]>;
  getCompetition(id: string): Promise<Competition | undefined>;
  createCompetition(competition: InsertCompetition): Promise<Competition>;
  updateCompetition(id: string, competition: Partial<InsertCompetition>): Promise<Competition | undefined>;
  deleteCompetition(id: string): Promise<void>;

  // Run Slots
  getRunSlots(competitionId?: string): Promise<RunSlot[]>;
  getRunSlot(id: string): Promise<RunSlot | undefined>;
  createRunSlot(runSlot: InsertRunSlot): Promise<RunSlot>;
  updateRunSlot(id: string, runSlot: Partial<InsertRunSlot>): Promise<RunSlot | undefined>;
  deleteRunSlot(id: string): Promise<void>;

  // Convention Classes
  getConventionClasses(competitionId?: string): Promise<ConventionClass[]>;
  getConventionClass(id: string): Promise<ConventionClass | undefined>;
  createConventionClass(conventionClass: InsertConventionClass): Promise<ConventionClass>;
  updateConventionClass(id: string, conventionClass: Partial<InsertConventionClass>): Promise<ConventionClass | undefined>;
  deleteConventionClass(id: string): Promise<void>;

  // Studio Classes
  getStudioClasses(): Promise<StudioClass[]>;
  getStudioClass(id: string): Promise<StudioClass | undefined>;
  createStudioClass(studioClass: InsertStudioClass): Promise<StudioClass>;
  updateStudioClass(id: string, studioClass: Partial<InsertStudioClass>): Promise<StudioClass | undefined>;
  deleteStudioClass(id: string): Promise<void>;

  // Practice Bookings
  getPracticeBookings(): Promise<PracticeBooking[]>;
  getPracticeBooking(id: string): Promise<PracticeBooking | undefined>;
  createPracticeBooking(booking: InsertPracticeBooking): Promise<PracticeBooking>;
  updatePracticeBooking(id: string, booking: Partial<InsertPracticeBooking>): Promise<PracticeBooking | undefined>;
  deletePracticeBooking(id: string): Promise<void>;

  // Announcements
  getAnnouncements(): Promise<Announcement[]>;
  getAnnouncement(id: string): Promise<Announcement | undefined>;
  createAnnouncement(announcement: InsertAnnouncement): Promise<Announcement>;
  updateAnnouncement(id: string, announcement: Partial<InsertAnnouncement>): Promise<Announcement | undefined>;
  deleteAnnouncement(id: string): Promise<void>;

  // Fees
  getFees(dancerId?: string): Promise<Fee[]>;
  getFee(id: string): Promise<Fee | undefined>;
  createFee(fee: InsertFee): Promise<Fee>;
  updateFee(id: string, fee: Partial<InsertFee>): Promise<Fee | undefined>;
  deleteFee(id: string): Promise<void>;
}

export class DatabaseStorage implements IStorage {
  // Dancers
  async getDancers(): Promise<Dancer[]> {
    return await db.select().from(dancers);
  }

  async getDancer(id: string): Promise<Dancer | undefined> {
    const result = await db.select().from(dancers).where(eq(dancers.id, id));
    return result[0];
  }

  async createDancer(dancer: InsertDancer): Promise<Dancer> {
    const result = await db.insert(dancers).values(dancer).returning();
    return result[0];
  }

  async updateDancer(id: string, dancer: Partial<InsertDancer>): Promise<Dancer | undefined> {
    const result = await db.update(dancers).set(dancer).where(eq(dancers.id, id)).returning();
    return result[0];
  }

  async deleteDancer(id: string): Promise<void> {
    await db.delete(dancers).where(eq(dancers.id, id));
  }

  // Teachers
  async getTeachers(): Promise<Teacher[]> {
    return await db.select().from(teachers);
  }

  async getTeacher(id: string): Promise<Teacher | undefined> {
    const result = await db.select().from(teachers).where(eq(teachers.id, id));
    return result[0];
  }

  async createTeacher(teacher: InsertTeacher): Promise<Teacher> {
    const result = await db.insert(teachers).values(teacher).returning();
    return result[0];
  }

  async updateTeacher(id: string, teacher: Partial<InsertTeacher>): Promise<Teacher | undefined> {
    const result = await db.update(teachers).set(teacher).where(eq(teachers.id, id)).returning();
    return result[0];
  }

  async deleteTeacher(id: string): Promise<void> {
    await db.delete(teachers).where(eq(teachers.id, id));
  }

  // Routines
  async getRoutines(): Promise<Routine[]> {
    return await db.select().from(routines);
  }

  async getRoutine(id: string): Promise<Routine | undefined> {
    const result = await db.select().from(routines).where(eq(routines.id, id));
    return result[0];
  }

  async createRoutine(routine: InsertRoutine): Promise<Routine> {
    const result = await db.insert(routines).values(routine).returning();
    return result[0];
  }

  async updateRoutine(id: string, routine: Partial<InsertRoutine>): Promise<Routine | undefined> {
    const result = await db.update(routines).set(routine).where(eq(routines.id, id)).returning();
    return result[0];
  }

  async deleteRoutine(id: string): Promise<void> {
    await db.delete(routines).where(eq(routines.id, id));
  }

  // Competitions
  async getCompetitions(): Promise<Competition[]> {
    return await db.select().from(competitions);
  }

  async getCompetition(id: string): Promise<Competition | undefined> {
    const result = await db.select().from(competitions).where(eq(competitions.id, id));
    return result[0];
  }

  async createCompetition(competition: InsertCompetition): Promise<Competition> {
    const result = await db.insert(competitions).values(competition).returning();
    return result[0];
  }

  async updateCompetition(id: string, competition: Partial<InsertCompetition>): Promise<Competition | undefined> {
    const result = await db.update(competitions).set(competition).where(eq(competitions.id, id)).returning();
    return result[0];
  }

  async deleteCompetition(id: string): Promise<void> {
    await db.delete(competitions).where(eq(competitions.id, id));
  }

  // Run Slots
  async getRunSlots(competitionId?: string): Promise<RunSlot[]> {
    if (competitionId) {
      return await db.select().from(runSlots).where(eq(runSlots.competitionId, competitionId));
    }
    return await db.select().from(runSlots);
  }

  async getRunSlot(id: string): Promise<RunSlot | undefined> {
    const result = await db.select().from(runSlots).where(eq(runSlots.id, id));
    return result[0];
  }

  async createRunSlot(runSlot: InsertRunSlot): Promise<RunSlot> {
    const result = await db.insert(runSlots).values(runSlot).returning();
    return result[0];
  }

  async updateRunSlot(id: string, runSlot: Partial<InsertRunSlot>): Promise<RunSlot | undefined> {
    const result = await db.update(runSlots).set(runSlot).where(eq(runSlots.id, id)).returning();
    return result[0];
  }

  async deleteRunSlot(id: string): Promise<void> {
    await db.delete(runSlots).where(eq(runSlots.id, id));
  }

  // Convention Classes
  async getConventionClasses(competitionId?: string): Promise<ConventionClass[]> {
    if (competitionId) {
      return await db.select().from(conventionClasses).where(eq(conventionClasses.competitionId, competitionId));
    }
    return await db.select().from(conventionClasses);
  }

  async getConventionClass(id: string): Promise<ConventionClass | undefined> {
    const result = await db.select().from(conventionClasses).where(eq(conventionClasses.id, id));
    return result[0];
  }

  async createConventionClass(conventionClass: InsertConventionClass): Promise<ConventionClass> {
    const result = await db.insert(conventionClasses).values(conventionClass).returning();
    return result[0];
  }

  async updateConventionClass(id: string, conventionClass: Partial<InsertConventionClass>): Promise<ConventionClass | undefined> {
    const result = await db.update(conventionClasses).set(conventionClass).where(eq(conventionClasses.id, id)).returning();
    return result[0];
  }

  async deleteConventionClass(id: string): Promise<void> {
    await db.delete(conventionClasses).where(eq(conventionClasses.id, id));
  }

  // Studio Classes
  async getStudioClasses(): Promise<StudioClass[]> {
    return await db.select().from(studioClasses);
  }

  async getStudioClass(id: string): Promise<StudioClass | undefined> {
    const result = await db.select().from(studioClasses).where(eq(studioClasses.id, id));
    return result[0];
  }

  async createStudioClass(studioClass: InsertStudioClass): Promise<StudioClass> {
    const result = await db.insert(studioClasses).values(studioClass).returning();
    return result[0];
  }

  async updateStudioClass(id: string, studioClass: Partial<InsertStudioClass>): Promise<StudioClass | undefined> {
    const result = await db.update(studioClasses).set(studioClass).where(eq(studioClasses.id, id)).returning();
    return result[0];
  }

  async deleteStudioClass(id: string): Promise<void> {
    await db.delete(studioClasses).where(eq(studioClasses.id, id));
  }

  // Practice Bookings
  async getPracticeBookings(): Promise<PracticeBooking[]> {
    return await db.select().from(practiceBookings);
  }

  async getPracticeBooking(id: string): Promise<PracticeBooking | undefined> {
    const result = await db.select().from(practiceBookings).where(eq(practiceBookings.id, id));
    return result[0];
  }

  async createPracticeBooking(booking: InsertPracticeBooking): Promise<PracticeBooking> {
    const result = await db.insert(practiceBookings).values(booking).returning();
    return result[0];
  }

  async updatePracticeBooking(id: string, booking: Partial<InsertPracticeBooking>): Promise<PracticeBooking | undefined> {
    const result = await db.update(practiceBookings).set(booking).where(eq(practiceBookings.id, id)).returning();
    return result[0];
  }

  async deletePracticeBooking(id: string): Promise<void> {
    await db.delete(practiceBookings).where(eq(practiceBookings.id, id));
  }

  // Announcements
  async getAnnouncements(): Promise<Announcement[]> {
    return await db.select().from(announcements);
  }

  async getAnnouncement(id: string): Promise<Announcement | undefined> {
    const result = await db.select().from(announcements).where(eq(announcements.id, id));
    return result[0];
  }

  async createAnnouncement(announcement: InsertAnnouncement): Promise<Announcement> {
    const result = await db.insert(announcements).values(announcement).returning();
    return result[0];
  }

  async updateAnnouncement(id: string, announcement: Partial<InsertAnnouncement>): Promise<Announcement | undefined> {
    const result = await db.update(announcements).set(announcement).where(eq(announcements.id, id)).returning();
    return result[0];
  }

  async deleteAnnouncement(id: string): Promise<void> {
    await db.delete(announcements).where(eq(announcements.id, id));
  }

  // Fees
  async getFees(dancerId?: string): Promise<Fee[]> {
    if (dancerId) {
      return await db.select().from(fees).where(eq(fees.dancerId, dancerId));
    }
    return await db.select().from(fees);
  }

  async getFee(id: string): Promise<Fee | undefined> {
    const result = await db.select().from(fees).where(eq(fees.id, id));
    return result[0];
  }

  async createFee(fee: InsertFee): Promise<Fee> {
    const result = await db.insert(fees).values(fee).returning();
    return result[0];
  }

  async updateFee(id: string, fee: Partial<InsertFee>): Promise<Fee | undefined> {
    const result = await db.update(fees).set(fee).where(eq(fees.id, id)).returning();
    return result[0];
  }

  async deleteFee(id: string): Promise<void> {
    await db.delete(fees).where(eq(fees.id, id));
  }
}

export const storage = new DatabaseStorage();
