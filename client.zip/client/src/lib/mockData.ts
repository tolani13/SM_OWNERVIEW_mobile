export interface Dancer {
  id: string;
  firstName: string;
  lastName: string;
  age: number;
  level: "Mini" | "Junior" | "Teen" | "Senior" | "Elite";
  status: "Active" | "Inactive";
  email?: string;
  parentName?: string;
  parentPhone?: string;
  parentEmail?: string;
  emergencyContact?: string;
  studioNotes?: string;
}

export interface Teacher {
  id: string;
  name: string;
  role: string;
  avatarUrl?: string;
  classes: string[]; // List of class names
  isAvailableForSolo: boolean;
}

export interface Routine {
  id: string;
  name: string;
  style: "Jazz" | "Lyrical" | "Contemporary" | "Tap" | "Hip Hop" | "Ballet" | "Open";
  type: "Solo" | "Duet" | "Trio" | "Small Group" | "Large Group" | "Line" | "Production";
  dancerIds: string[];
  paidDancerIds?: string[];
  costumeFee: number;
  costumeName?: string;
  costumePaid?: boolean;
}

export interface Competition {
  id: string;
  name: string;
  location: string;
  startDate: string;
  endDate: string;
  status: "Upcoming" | "Completed";
  logoUrl?: string;
}

export interface RunSlot {
  id: string;
  competitionId: string;
  routineId: string; // or null if it's not our studio? No, let's assume we only track ours or manual entries.
  // Actually, for a run sheet we might want to track other studios' routines to know order, but typically we just track ours + breaks. 
  // But the requirement says "Highlight 'our' studio's routines", implying there might be others. 
  // For now I'll stick to ID. If ID matches a routine in ROUTINES, it's ours.
  day: string;
  time: string; // "14:30"
  stage: string;
  orderNumber: number;
  category: string;
  notes: string;
  placement?: string;
  specialAward?: string;
  isStudioRoutine?: boolean; // explicit flag helper
  studio?: string; // New field for studio name
}

export interface StudioClass {
  id: string;
  name: string;
  day: string; // Changed to string to support specific dates for special events
  time: string;
  teacherId: string;
  level: string;
  type: "Weekly" | "Special";
  description?: string;
  cost?: number; // For special events
}

export interface PracticeBooking {
  id: string;
  title: string;
  date: string;
  startTime: string;
  endTime: string;
  room: string;
  bookedBy: string;
}

export interface Announcement {
  id: string;
  title: string;
  content: string;
  date: string;
  tags: ("Studio" | "Competition" | "Level")[];
  status: "Active" | "Archived";
  isPinned?: boolean;
}

export interface Fee {
  id: string;
  type: "Tuition" | "Competition" | "Costume";
  amount: number;
  paid: boolean;
  dueDate: string;
  dancerId: string;
  // For comp/costume fees
  competitionId?: string;
  routineId?: string;
}

export interface ConventionClass {
  id: string;
  competitionId: string;
  day: string;
  time: string;
  name: string; // e.g., "Senior Jazz"
  teacher: string;
  room: string;
  level: string;
}

export const TUITION_RATES = {
  "Mini": 140,
  "Junior": 180,
  "Teen": 220,
  "Senior": 250,
  "Elite": 280
};

// --- MOCK DATA STORE ---

export const DANCERS: Dancer[] = [
  { id: "d1", firstName: "Emma", lastName: "Roberts", age: 10, level: "Mini", status: "Active", parentName: "Julia Roberts", parentPhone: "555-0101", studioNotes: "Peanut allergy" },
  { id: "d2", firstName: "Sophia", lastName: "Liu", age: 12, level: "Junior", status: "Active", parentName: "David Liu", parentPhone: "555-0102" },
  { id: "d3", firstName: "Ava", lastName: "Smith", age: 15, level: "Teen", status: "Active", parentName: "John Smith", parentPhone: "555-0103" },
  { id: "d4", firstName: "Mia", lastName: "Johnson", age: 8, level: "Mini", status: "Active", parentName: "Alice Johnson", parentPhone: "555-0104" },
  { id: "d5", firstName: "Charlotte", lastName: "Brown", age: 17, level: "Senior", status: "Active", parentName: "Charlie Brown", parentPhone: "555-0105", studioNotes: "Knee injury recovery" },
  { id: "d6", firstName: "Olivia", lastName: "Garcia", age: 13, level: "Junior", status: "Inactive", parentName: "Maria Garcia", parentPhone: "555-0106" },
  { id: "d7", firstName: "Isabella", lastName: "Martinez", age: 16, level: "Teen", status: "Active", parentName: "Luis Martinez", parentPhone: "555-0107" },
];

export const TEACHERS: Teacher[] = [
  { id: "t1", name: "Sarah Miller", role: "Artistic Director", classes: ["Senior Jazz", "Company Tech"], avatarUrl: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=150&h=150&fit=crop", isAvailableForSolo: true },
  { id: "t2", name: "James Chen", role: "Hip Hop Instructor", classes: ["Boys Hip Hop", "Junior Crew"], avatarUrl: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&h=150&fit=crop", isAvailableForSolo: false },
  { id: "t3", name: "Elena Volkov", role: "Ballet Mistress", classes: ["Pointe II", "Ballet III"], avatarUrl: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=150&h=150&fit=crop", isAvailableForSolo: true },
];

export const ROUTINES: Routine[] = [
  { id: "r1", name: "Rhythm of the Night", style: "Jazz", type: "Large Group", dancerIds: ["d1", "d2", "d3", "d4", "d5", "d7"], costumeFee: 150, costumeName: "Neon Nights" },
  { id: "r2", name: "Reflection", style: "Lyrical", type: "Solo", dancerIds: ["d3"], costumeFee: 200, costumeName: "Silver Mirror" },
  { id: "r3", name: "Get Down", style: "Hip Hop", type: "Small Group", dancerIds: ["d2", "d4", "d6"], costumeFee: 130, costumeName: "Street Crew" },
  { id: "r4", name: "Moonlight", style: "Contemporary", type: "Duet", dancerIds: ["d5", "d7"], costumeFee: 180, costumeName: "Midnight Blue" },
];

export const COMPETITIONS: Competition[] = [
  { id: "c1", name: "Velocity Dance Convention", location: "Palm Springs, CA", startDate: "2025-11-21", endDate: "2025-11-23", status: "Upcoming" },
  { id: "c2", name: "Biloxi Season 30", location: "Biloxi, MS", startDate: "2025-12-05", endDate: "2025-12-07", status: "Upcoming" },
];

export const RUN_SLOTS: RunSlot[] = [
  // --- Velocity (Palm Springs) ---
  // Friday (Teen/Senior Competition)
  { id: "rs101", competitionId: "c1", routineId: "r_manual_1", day: "Friday", time: "17:30", stage: "Main", orderNumber: 1, category: "Teen Small Group Contemp", notes: "The Studance Lab", isStudioRoutine: false },
  { id: "rs102", competitionId: "c1", routineId: "r_manual_2", day: "Friday", time: "17:34", stage: "Main", orderNumber: 2, category: "Teen Duet/Trio Contemp", notes: "Baxter Dance Training", isStudioRoutine: false },
  { id: "rs103", competitionId: "c1", routineId: "r_manual_3", day: "Friday", time: "17:37", stage: "Main", orderNumber: 3, category: "Teen Duet/Trio Contemp", notes: "Baxter Dance Training", isStudioRoutine: false },
  { id: "rs104", competitionId: "c1", routineId: "r4", day: "Friday", time: "17:39", stage: "Main", orderNumber: 4, category: "Teen Small Group Contemp", notes: "Suit and Jacket - Evolution Dance Center", isStudioRoutine: true }, // Marked as ours
  { id: "rs105", competitionId: "c1", routineId: "r_manual_5", day: "Friday", time: "17:42", stage: "Main", orderNumber: 5, category: "Teen Large Group Contemp", notes: "Inside of Us", isStudioRoutine: true }, // Marked as ours
  { id: "rs106", competitionId: "c1", routineId: "r_manual_6", day: "Friday", time: "17:45", stage: "Main", orderNumber: 6, category: "Teen Duet/Trio Lyrical", notes: "Helium", isStudioRoutine: false },
  { id: "rs107", competitionId: "c1", routineId: "r_manual_7", day: "Friday", time: "17:49", stage: "Main", orderNumber: 7, category: "Teen Small Group Contemp", notes: "The End of Love", isStudioRoutine: false },
  { id: "rs110", competitionId: "c1", routineId: "r2", day: "Friday", time: "17:58", stage: "Main", orderNumber: 10, category: "Senior Solo Contemp", notes: "Don't Worry About Me - Sara Roach", isStudioRoutine: true }, // Ours

  // Saturday (Mini/Junior)
  { id: "rs170", competitionId: "c1", routineId: "r_manual_70", day: "Saturday", time: "15:00", stage: "Main", orderNumber: 70, category: "Mini Solo Contemp", notes: "Send In The Clowns", isStudioRoutine: false },
  { id: "rs171", competitionId: "c1", routineId: "r_manual_71", day: "Saturday", time: "15:02", stage: "Main", orderNumber: 71, category: "Mini Solo Contemp", notes: "Formula", isStudioRoutine: false },
  { id: "rs172", competitionId: "c1", routineId: "r1", day: "Saturday", time: "15:05", stage: "Main", orderNumber: 72, category: "Mini Solo Contemp", notes: "Survivor - Imperium", isStudioRoutine: true }, // Ours

  // --- Biloxi Season 30 ---
  // Friday (Mini Solos)
  { id: "rs201", competitionId: "c2", routineId: "r_manual_b1", day: "Friday", time: "08:00", stage: "Main", orderNumber: 1, category: "Mini Jazz Solo", notes: "Party In The USA", isStudioRoutine: false },
  { id: "rs202", competitionId: "c2", routineId: "r_manual_b2", day: "Friday", time: "08:02", stage: "Main", orderNumber: 2, category: "Mini Jazz Solo", notes: "Buzz", isStudioRoutine: false },
  { id: "rs203", competitionId: "c2", routineId: "r3", day: "Friday", time: "08:04", stage: "Main", orderNumber: 3, category: "Mini Jazz Solo", notes: "Little Bitty Pretty One", isStudioRoutine: true }, // Ours
  { id: "rs204", competitionId: "c2", routineId: "r_manual_b4", day: "Friday", time: "08:06", stage: "Main", orderNumber: 4, category: "Mini Jazz Solo", notes: "Wow", isStudioRoutine: false },
  { id: "rs205", competitionId: "c2", routineId: "r_manual_b5", day: "Friday", time: "08:09", stage: "Main", orderNumber: 5, category: "Mini Jazz Solo", notes: "Be About It", isStudioRoutine: false },
  { id: "rs210", competitionId: "c2", routineId: "r_manual_b10", day: "Friday", time: "08:21", stage: "Main", orderNumber: 10, category: "Mini Contemp Solo", notes: "Mystery In Darkness", isStudioRoutine: true }, // Ours
];

export const CONVENTION_CLASSES: ConventionClass[] = [
  // --- Velocity (Palm Springs) ---
  // Saturday - Mini
  { id: "cc101", competitionId: "c1", day: "Saturday", time: "08:00", name: "Jazz", teacher: "Jeremy Hudson", room: "Mini Room", level: "Mini" },
  { id: "cc102", competitionId: "c1", day: "Saturday", time: "09:00", name: "Hip-Hop", teacher: "Redd", room: "Mini Room", level: "Mini" },
  { id: "cc103", competitionId: "c1", day: "Saturday", time: "10:15", name: "Ballet", teacher: "Melissa Sandvig", room: "Mini Room", level: "Mini" },
  // Saturday - Junior
  { id: "cc104", competitionId: "c1", day: "Saturday", time: "08:00", name: "Contemporary", teacher: "Whitney Bezzant", room: "Junior Room", level: "Junior" },
  { id: "cc105", competitionId: "c1", day: "Saturday", time: "09:00", name: "Tap", teacher: "Mark Goodman", room: "Junior Room", level: "Junior" },
  // Saturday - Teen
  { id: "cc106", competitionId: "c1", day: "Saturday", time: "08:00", name: "Ballet", teacher: "Melissa Sandvig", room: "Teen Room", level: "Teen" },
  { id: "cc107", competitionId: "c1", day: "Saturday", time: "09:00", name: "Scholarship Audition", teacher: "Whitney Bezzant", room: "Teen Room", level: "Teen" },

  // --- Biloxi Season 30 ---
  // Saturday - Mini
  { id: "cc201", competitionId: "c2", day: "Saturday", time: "07:45", name: "Ballet", teacher: "Tiffany Billings", room: "Mini Room", level: "Mini" },
  { id: "cc202", competitionId: "c2", day: "Saturday", time: "08:50", name: "Tap", teacher: "Nick Bowman", room: "Mini Room", level: "Mini" },
  // Saturday - Junior
  { id: "cc203", competitionId: "c2", day: "Saturday", time: "07:45", name: "Industry Jazz", teacher: "Scott Myrick", room: "Junior Room", level: "Junior" },
  { id: "cc204", competitionId: "c2", day: "Saturday", time: "08:50", name: "Ballet", teacher: "Tiffany Billings", room: "Junior Room", level: "Junior" },
  // Saturday - Teen/Senior
  { id: "cc205", competitionId: "c2", day: "Saturday", time: "07:45", name: "Contemporary", teacher: "Will Johnston", room: "Teen Room", level: "Teen/Senior" },
  { id: "cc206", competitionId: "c2", day: "Saturday", time: "08:50", name: "Jazz", teacher: "Aika Doone", room: "Teen Room", level: "Teen/Senior" },
];

export const CLASSES: StudioClass[] = [
  { id: "sc1", name: "Ballet III", day: "Monday", time: "16:30", teacherId: "t3", level: "Teen/Senior", type: "Weekly" },
  { id: "sc2", name: "Jazz Tech", day: "Monday", time: "18:00", teacherId: "t1", level: "Teen", type: "Weekly" },
  { id: "sc3", name: "Mini Hip Hop", day: "Tuesday", time: "16:00", teacherId: "t2", level: "Mini", type: "Weekly" },
  { id: "sc4", name: "Company Rehearsal", day: "Wednesday", time: "17:00", teacherId: "t1", level: "All Company", type: "Weekly" },
  { id: "sc5", name: "Guest Masterclass: Contemporary", day: "2024-03-20", time: "18:00", teacherId: "t1", level: "Senior/Elite", type: "Special", description: "Special workshop with Travis Wall", cost: 45 },
];

export const BOOKINGS: PracticeBooking[] = [
  { id: "pb1", title: "Emma Solo Rehearsal", date: "2024-03-01", startTime: "15:00", endTime: "16:00", room: "Studio A", bookedBy: "Sarah" },
  { id: "pb2", title: "Duet Clean Up", date: "2024-03-02", startTime: "12:00", endTime: "13:30", room: "Studio B", bookedBy: "Elena" },
];

export const ANNOUNCEMENTS: Announcement[] = [
  { id: "a0", title: "Studio Policy: Weather Cancellations", content: "We follow the local school district for weather closures.", date: "2023-09-01T00:00:00", tags: ["Studio"], status: "Active", isPinned: true },
  { id: "a1", title: "Recital Costume Measurements", content: "Please have all measurements submitted by Friday.", date: "2024-02-28T09:00:00", tags: ["Studio"], status: "Active", isPinned: false },
  { id: "a2", title: "Starpower Hotel Block", content: "The room block expires next week. Book now!", date: "2024-02-25T14:30:00", tags: ["Competition"], status: "Active", isPinned: false },
];

export const FEES: Fee[] = [
  // Tuition
  { id: "f1", type: "Tuition", amount: 140, paid: true, dueDate: "2024-03-01", dancerId: "d1" }, // Mini
  { id: "f2", type: "Tuition", amount: 180, paid: false, dueDate: "2024-03-01", dancerId: "d2" }, // Junior
  { id: "f3", type: "Tuition", amount: 220, paid: true, dueDate: "2024-03-01", dancerId: "d3" }, // Teen
  // Comp Fees (Starpower)
  { id: "f4", type: "Competition", amount: 65, paid: true, dueDate: "2024-02-15", dancerId: "d1", competitionId: "c1" },
  { id: "f5", type: "Competition", amount: 65, paid: false, dueDate: "2024-02-15", dancerId: "d2", competitionId: "c1" },
  // Costume Fees
  { id: "f6", type: "Costume", amount: 150, paid: true, dueDate: "2023-11-15", dancerId: "d3", routineId: "r1" }, // Group
  { id: "f7", type: "Costume", amount: 200, paid: false, dueDate: "2023-11-15", dancerId: "d3", routineId: "r2" }, // Solo (Unpaid)
];

// Helpers
export const getDancerName = (id: string) => {
  const d = DANCERS.find(d => d.id === id);
  if (!d) return "Unknown";
  return `${d.firstName} ${d.lastName.charAt(0)}.`; // Masked
};

export const getDancerFullName = (id: string) => {
    const d = DANCERS.find(d => d.id === id);
    if (!d) return "Unknown";
    return `${d.firstName} ${d.lastName}`;
  };

export const getTeacherName = (id: string) => {
  const t = TEACHERS.find(t => t.id === id);
  return t ? t.name : "Unknown";
};

export const getRoutineName = (id: string) => {
  const r = ROUTINES.find(r => r.id === id);
  return r ? r.name : "Unknown";
};

export const getCompetitionName = (id: string) => {
    const c = COMPETITIONS.find(c => c.id === id);
    return c ? c.name : "Unknown";
  };
