import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { dancersAPI, teachersAPI, routinesAPI, competitionsAPI, runSlotsAPI, conventionClassesAPI, studioClassesAPI, practiceBookingsAPI, announcementsAPI, feesAPI } from "@/lib/api";
import type { InsertDancer, InsertTeacher, InsertRoutine, InsertCompetition, InsertRunSlot, InsertConventionClass, InsertStudioClass, InsertPracticeBooking, InsertAnnouncement, InsertFee } from "@shared/schema";

// Dancers
export function useDancers() {
  return useQuery({
    queryKey: ["dancers"],
    queryFn: dancersAPI.getAll,
  });
}

export function useCreateDancer() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (data: InsertDancer) => dancersAPI.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["dancers"] });
    },
  });
}

export function useUpdateDancer() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: ({ id, data }: { id: string; data: Partial<InsertDancer> }) => dancersAPI.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["dancers"] });
    },
  });
}

export function useDeleteDancer() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (id: string) => dancersAPI.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["dancers"] });
    },
  });
}

// Teachers
export function useTeachers() {
  return useQuery({
    queryKey: ["teachers"],
    queryFn: teachersAPI.getAll,
  });
}

export function useCreateTeacher() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (data: InsertTeacher) => teachersAPI.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["teachers"] });
    },
  });
}

export function useUpdateTeacher() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: ({ id, data }: { id: string; data: Partial<InsertTeacher> }) => teachersAPI.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["teachers"] });
    },
  });
}

// Routines
export function useRoutines() {
  return useQuery({
    queryKey: ["routines"],
    queryFn: routinesAPI.getAll,
  });
}

export function useCreateRoutine() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (data: InsertRoutine) => routinesAPI.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["routines"] });
    },
  });
}

export function useUpdateRoutine() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: ({ id, data }: { id: string; data: Partial<InsertRoutine> }) => routinesAPI.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["routines"] });
    },
  });
}

export function useDeleteRoutine() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (id: string) => routinesAPI.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["routines"] });
    },
  });
}

// Competitions
export function useCompetitions() {
  return useQuery({
    queryKey: ["competitions"],
    queryFn: competitionsAPI.getAll,
  });
}

export function useCompetition(id: string) {
  return useQuery({
    queryKey: ["competitions", id],
    queryFn: () => competitionsAPI.getOne(id),
    enabled: !!id,
  });
}

export function useCreateCompetition() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (data: InsertCompetition) => competitionsAPI.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["competitions"] });
    },
  });
}

export function useUpdateCompetition() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: ({ id, data }: { id: string; data: Partial<InsertCompetition> }) => competitionsAPI.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["competitions"] });
    },
  });
}

// Run Slots
export function useRunSlots(competitionId?: string) {
  return useQuery({
    queryKey: ["runSlots", competitionId],
    queryFn: () => runSlotsAPI.getAll(competitionId),
  });
}

export function useCreateRunSlot() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (data: InsertRunSlot) => runSlotsAPI.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["runSlots"] });
    },
  });
}

export function useUpdateRunSlot() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: ({ id, data }: { id: string; data: Partial<InsertRunSlot> }) => runSlotsAPI.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["runSlots"] });
    },
  });
}

export function useDeleteRunSlot() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (id: string) => runSlotsAPI.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["runSlots"] });
    },
  });
}

// Convention Classes
export function useConventionClasses(competitionId?: string) {
  return useQuery({
    queryKey: ["conventionClasses", competitionId],
    queryFn: () => conventionClassesAPI.getAll(competitionId),
  });
}

export function useCreateConventionClass() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (data: InsertConventionClass) => conventionClassesAPI.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["conventionClasses"] });
    },
  });
}

export function useUpdateConventionClass() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: ({ id, data }: { id: string; data: Partial<InsertConventionClass> }) => conventionClassesAPI.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["conventionClasses"] });
    },
  });
}

export function useDeleteConventionClass() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (id: string) => conventionClassesAPI.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["conventionClasses"] });
    },
  });
}

// Studio Classes
export function useStudioClasses() {
  return useQuery({
    queryKey: ["studioClasses"],
    queryFn: studioClassesAPI.getAll,
  });
}

export function useCreateStudioClass() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (data: InsertStudioClass) => studioClassesAPI.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["studioClasses"] });
    },
  });
}

export function useUpdateStudioClass() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: ({ id, data }: { id: string; data: Partial<InsertStudioClass> }) => studioClassesAPI.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["studioClasses"] });
    },
  });
}

export function useDeleteStudioClass() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (id: string) => studioClassesAPI.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["studioClasses"] });
    },
  });
}

// Practice Bookings
export function usePracticeBookings() {
  return useQuery({
    queryKey: ["practiceBookings"],
    queryFn: practiceBookingsAPI.getAll,
  });
}

export function useCreatePracticeBooking() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (data: InsertPracticeBooking) => practiceBookingsAPI.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["practiceBookings"] });
    },
  });
}

export function useUpdatePracticeBooking() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: ({ id, data }: { id: string; data: Partial<InsertPracticeBooking> }) => practiceBookingsAPI.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["practiceBookings"] });
    },
  });
}

export function useDeletePracticeBooking() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (id: string) => practiceBookingsAPI.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["practiceBookings"] });
    },
  });
}

// Announcements
export function useAnnouncements() {
  return useQuery({
    queryKey: ["announcements"],
    queryFn: announcementsAPI.getAll,
  });
}

export function useCreateAnnouncement() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (data: InsertAnnouncement) => announcementsAPI.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["announcements"] });
    },
  });
}

export function useUpdateAnnouncement() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: ({ id, data }: { id: string; data: Partial<InsertAnnouncement> }) => announcementsAPI.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["announcements"] });
    },
  });
}

export function useDeleteAnnouncement() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (id: string) => announcementsAPI.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["announcements"] });
    },
  });
}

// Fees
export function useFees(dancerId?: string) {
  return useQuery({
    queryKey: ["fees", dancerId],
    queryFn: () => feesAPI.getAll(dancerId),
  });
}

export function useCreateFee() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (data: InsertFee) => feesAPI.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["fees"] });
    },
  });
}

export function useUpdateFee() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: ({ id, data }: { id: string; data: Partial<InsertFee> }) => feesAPI.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["fees"] });
    },
  });
}

export function useDeleteFee() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (id: string) => feesAPI.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["fees"] });
    },
  });
}
