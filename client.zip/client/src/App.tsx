import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";

import Dashboard from "@/pages/Dashboard";
import Studio from "@/pages/Studio";
import Dancers from "@/pages/Dancers";
import Routines from "@/pages/Routines";
import Competitions from "@/pages/Competitions";
import Finance from "@/pages/Finance";
import Announcements from "@/pages/Announcements";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Dashboard} />
      <Route path="/studio" component={Studio} />
      <Route path="/dancers" component={Dancers} />
      <Route path="/routines" component={Routines} />
      <Route path="/competitions" component={Competitions} />
      <Route path="/finance" component={Finance} />
      <Route path="/announcements" component={Announcements} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
