import { Layout } from "@/components/Layout";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Plus, Clock, MapPin, User, Calendar as CalendarIcon, Search, Star, CheckCircle2, XCircle, Edit2, Upload, DollarSign, Calendar } from "lucide-react";
import { useState } from "react";
import { cn } from "@/lib/utils";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { useStudioClasses, useCreateStudioClass, useUpdateStudioClass, useTeachers, useCreateTeacher, useUpdateTeacher, usePracticeBookings, useCreatePracticeBooking, useUpdatePracticeBooking } from "@/hooks/useData";
import type { StudioClass, Teacher, PracticeBooking, InsertStudioClass, InsertTeacher, InsertPracticeBooking } from "@shared/schema";

export default function Studio() {
  const { data: classes = [], isLoading: classesLoading } = useStudioClasses();
  const { data: teachers = [], isLoading: teachersLoading } = useTeachers();
  const { data: bookings = [], isLoading: bookingsLoading } = usePracticeBookings();

  // Helper function
  const getTeacherName = (teacherId: string | null | undefined) => {
    if (!teacherId) return "Unknown";
    const teacher = teachers.find(t => t.id === teacherId);
    return teacher ? teacher.name : "Unknown";
  };
  
  const createStudioClass = useCreateStudioClass();
  const updateStudioClass = useUpdateStudioClass();
  const createTeacher = useCreateTeacher();
  const updateTeacher = useUpdateTeacher();
  const createPracticeBooking = useCreatePracticeBooking();
  const updatePracticeBooking = useUpdatePracticeBooking();

  const [activeTab, setActiveTab] = useState("classes");
  
  // Modals state
  const [isAddClassOpen, setIsAddClassOpen] = useState(false);
  const [isAddTeacherOpen, setIsAddTeacherOpen] = useState(false);
  const [isAddBookingOpen, setIsAddBookingOpen] = useState(false);
  const [isTeacherScheduleOpen, setIsTeacherScheduleOpen] = useState(false);
  const [selectedTeacherForSchedule, setSelectedTeacherForSchedule] = useState<Teacher | null>(null);

  const DAYS = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"];

  // Form states
  const [newClass, setNewClass] = useState<Partial<InsertStudioClass>>({ type: "Weekly", level: "All Levels" });
  const [newTeacher, setNewTeacher] = useState<Partial<InsertTeacher>>({ isAvailableForSolo: false });
  const [newBooking, setNewBooking] = useState<Partial<InsertPracticeBooking>>({});
  
  // Edit states
  const [editingTeacherId, setEditingTeacherId] = useState<string | null>(null);
  const [editingClassId, setEditingClassId] = useState<string | null>(null);

  const handleAddClass = async () => {
    if (!newClass.name || !newClass.day || !newClass.time || !newClass.teacherId) return;
    
    if (editingClassId) {
        await updateStudioClass.mutateAsync({ id: editingClassId, data: newClass });
        setEditingClassId(null);
    } else {
        await createStudioClass.mutateAsync({
            name: newClass.name,
            day: newClass.day,
            time: newClass.time,
            teacherId: newClass.teacherId,
            level: newClass.level || "All Levels",
            type: newClass.type || "Weekly",
            description: newClass.description,
            cost: newClass.cost
        });
    }
    setIsAddClassOpen(false);
    setNewClass({ type: "Weekly", level: "All Levels" });
  };

  const openEditClass = (cls: StudioClass) => {
      setNewClass(cls);
      setEditingClassId(cls.id);
      setIsAddClassOpen(true);
  };

  const handleSaveTeacher = async () => {
    if (!newTeacher.name || !newTeacher.role) return;
    
    if (editingTeacherId) {
        // Update existing
        await updateTeacher.mutateAsync({ id: editingTeacherId, data: newTeacher });
        setEditingTeacherId(null);
    } else {
        // Create new
        await createTeacher.mutateAsync({
            name: newTeacher.name,
            role: newTeacher.role,
            isAvailableForSolo: newTeacher.isAvailableForSolo || false,
            avatarUrl: newTeacher.avatarUrl || `https://api.dicebear.com/7.x/avataaars/svg?seed=${newTeacher.name}`,
            classes: []
        });
    }
    setIsAddTeacherOpen(false);
    setNewTeacher({ isAvailableForSolo: false });
  };

  const openEditTeacher = (teacher: Teacher) => {
      setNewTeacher(teacher);
      setEditingTeacherId(teacher.id);
      setIsAddTeacherOpen(true);
  };

    const [editingBookingId, setEditingBookingId] = useState<string | null>(null);

    const handleAddBooking = async () => {
        if (!newBooking.title || !newBooking.date || !newBooking.startTime) return;
        
        if (editingBookingId) {
            await updatePracticeBooking.mutateAsync({ id: editingBookingId, data: newBooking });
            setEditingBookingId(null);
        } else {
            await createPracticeBooking.mutateAsync({
                title: newBooking.title,
                date: newBooking.date,
                startTime: newBooking.startTime,
                endTime: newBooking.endTime || "",
                room: newBooking.room || "Studio A",
                bookedBy: newBooking.bookedBy || "Staff"
            });
        }
        setIsAddBookingOpen(false);
        setNewBooking({});
    };

    const openEditBooking = (booking: PracticeBooking) => {
        setNewBooking(booking);
        setEditingBookingId(booking.id);
        setIsAddBookingOpen(true);
    };

  const specialClasses = classes.filter(c => c.type === "Special");
  const weeklyClasses = classes.filter(c => c.type === "Weekly" || !c.type);

  // Helper for mock calendar slots
  const mockTimeSlots = ["15:00", "15:30", "16:00", "16:30", "17:00", "17:30", "18:00"];
  const mockWeekDays = ["Mon", "Tue", "Wed", "Thu", "Fri"];

  if (classesLoading || teachersLoading || bookingsLoading) {
    return (
      <Layout>
        <div className="flex items-center justify-center h-64">
          <div className="text-muted-foreground">Loading...</div>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="space-y-6">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
            <div>
                <h1 className="text-3xl font-display font-bold text-foreground">Studio Management</h1>
                <p className="text-muted-foreground">Manage schedule, bookings, and staff.</p>
            </div>
            <div className="flex gap-2">
                 <Button 
                    className="bg-primary hover:bg-primary/90 text-white font-medium shadow-sm"
                    onClick={() => {
                        if (activeTab === "teachers") {
                            setNewTeacher({ classes: [], isAvailableForSolo: false });
                            setEditingTeacherId(null);
                            setIsAddTeacherOpen(true);
                        }
                        else if (activeTab === "bookings") {
                            setNewBooking({});
                            setEditingBookingId(null);
                            setIsAddBookingOpen(true);
                        }
                        else {
                            setNewClass({ type: "Weekly", level: "All Levels" });
                            setEditingClassId(null);
                            setIsAddClassOpen(true);
                        }
                    }}
                 >
                    <Plus className="w-4 h-4 mr-2" />
                    Add {activeTab === "teachers" ? "Teacher" : activeTab === "bookings" ? "Booking" : "Class"}
                 </Button>
            </div>
        </div>

        <Tabs defaultValue="classes" className="w-full" onValueChange={setActiveTab}>
          <TabsList className="bg-white/50 border p-1 h-auto mb-6">
            <TabsTrigger value="classes" className="data-[state=active]:bg-primary data-[state=active]:text-white py-2 px-4 rounded-md transition-colors">Weekly Schedule</TabsTrigger>
            <TabsTrigger value="special" className="data-[state=active]:bg-primary data-[state=active]:text-white py-2 px-4 rounded-md transition-colors">Special Events</TabsTrigger>
            <TabsTrigger value="bookings" className="data-[state=active]:bg-primary data-[state=active]:text-white py-2 px-4 rounded-md transition-colors">Room Bookings</TabsTrigger>
            <TabsTrigger value="teachers" className="data-[state=active]:bg-primary data-[state=active]:text-white py-2 px-4 rounded-md transition-colors">Teachers</TabsTrigger>
          </TabsList>

          <TabsContent value="classes" className="space-y-6 animate-in fade-in slide-in-from-bottom-2 duration-300">
            <div className="grid gap-6">
                {DAYS.map((day) => {
                    const classesForDay = weeklyClasses.filter(c => c.day === day).sort((a,b) => a.time.localeCompare(b.time));
                    if (classesForDay.length === 0) return null;
                    
                    return (
                        <Card key={day} className="border-none shadow-sm bg-white overflow-hidden group">
                            <div className="h-2 bg-primary w-full origin-left group-hover:scale-x-105 transition-transform" />
                            <CardHeader className="pb-3 border-b border-gray-50 bg-secondary/20">
                                <CardTitle className="text-lg font-medium text-foreground">{day}</CardTitle>
                            </CardHeader>
                            <CardContent className="p-0">
                                <div className="divide-y divide-gray-100">
                                    {classesForDay.map(cls => (
                                        <div key={cls.id} className="p-4 flex items-center justify-between hover:bg-gray-50 transition-colors">
                                            <div className="flex items-center gap-4">
                                                <div className="w-20 font-mono text-sm font-semibold text-primary">{cls.time}</div>
                                                <div>
                                                    <h4 className="font-semibold text-foreground">{cls.name}</h4>
                                                    <div className="flex items-center gap-2 text-xs text-muted-foreground mt-1">
                                                        <span className="bg-secondary px-2 py-0.5 rounded-full text-secondary-foreground font-medium">{cls.level}</span>
                                                        <span className="flex items-center gap-1"><User className="w-3 h-3" /> {getTeacherName(cls.teacherId)}</span>
                                                    </div>
                                                </div>
                                            </div>
                                            <Button 
                                                variant="ghost" 
                                                size="sm" 
                                                className="text-muted-foreground"
                                                onClick={() => openEditClass(cls)}
                                            >
                                                Edit
                                            </Button>
                                        </div>
                                    ))}
                                </div>
                            </CardContent>
                        </Card>
                    )
                })}
            </div>
          </TabsContent>

          <TabsContent value="special" className="space-y-6 animate-in fade-in slide-in-from-bottom-2 duration-300">
             {specialClasses.length === 0 ? (
                 <div className="text-center py-12 text-muted-foreground bg-white rounded-lg border border-dashed">
                     <Star className="w-12 h-12 mx-auto text-yellow-400 mb-4 opacity-50" />
                     <h3 className="text-lg font-medium text-foreground">No Special Events</h3>
                     <p>Add guest choreographers or masterclasses here.</p>
                 </div>
             ) : (
                 <div className="grid md:grid-cols-2 gap-6">
                     {specialClasses.map(cls => (
                         <Card key={cls.id} className="border-none shadow-sm hover:shadow-md transition-shadow group overflow-hidden bg-white">
                             <div className="h-2 bg-primary w-full origin-left group-hover:scale-x-105 transition-transform" />
                             <CardContent className="p-6">
                                 <div className="flex justify-between items-start mb-4">
                                     <Badge variant="outline" className="bg-purple-50 text-purple-700 border-purple-200">
                                         Special Event
                                     </Badge>
                                     <Button 
                                        variant="ghost" 
                                        size="icon" 
                                        className="h-8 w-8 text-muted-foreground hover:text-foreground opacity-0 group-hover:opacity-100 transition-opacity"
                                        onClick={() => openEditClass(cls)}
                                     >
                                        <Edit2 className="w-4 h-4" />
                                     </Button>
                                 </div>
                                 <h3 className="text-xl font-bold mb-2">{cls.name}</h3>
                                 <div className="flex items-center gap-4 text-sm text-muted-foreground mb-4">
                                     <span className="flex items-center gap-1"><CalendarIcon className="w-4 h-4" /> {cls.day}</span>
                                     <span className="flex items-center gap-1"><Clock className="w-4 h-4" /> {cls.time}</span>
                                 </div>
                                 <p className="text-sm text-muted-foreground mb-4">{cls.description}</p>
                                 
                                 {cls.cost && parseFloat(cls.cost) > 0 && (
                                     <div className="mb-4">
                                         <Badge className="bg-green-100 text-green-700 hover:bg-green-100 border-none shadow-none flex w-fit items-center gap-1">
                                             <DollarSign className="w-3 h-3" /> ${cls.cost} / dancer
                                         </Badge>
                                     </div>
                                 )}

                                 <div className="flex items-center justify-between pt-4 border-t">
                                     <div className="flex items-center gap-2">
                                         <User className="w-4 h-4 text-purple-600" />
                                         <span className="font-medium text-sm">{getTeacherName(cls.teacherId)}</span>
                                     </div>
                                     <span className="text-xs font-semibold bg-secondary px-2 py-1 rounded">{cls.level}</span>
                                 </div>
                             </CardContent>
                         </Card>
                     ))}
                 </div>
             )}
          </TabsContent>

          <TabsContent value="bookings" className="space-y-6 animate-in fade-in slide-in-from-bottom-2 duration-300">
            <Card className="border-none shadow-sm bg-white group overflow-hidden">
                <div className="h-2 bg-primary w-full origin-left group-hover:scale-x-105 transition-transform" />
                <CardHeader>
                    <div className="flex justify-between items-center">
                        <div>
                            <CardTitle>Practice & Private Rehearsals</CardTitle>
                            <CardDescription>Reserve studio space for private lessons or small group practice.</CardDescription>
                        </div>
                        <Button variant="outline" onClick={() => {
                            setNewBooking({});
                            setEditingBookingId(null);
                            setIsAddBookingOpen(true);
                        }}>Manage Bookings</Button>
                    </div>
                </CardHeader>
                <CardContent>
                    <div className="space-y-4">
                        {bookings.map(booking => (
                            <div key={booking.id} className="relative flex items-start md:items-center justify-between p-4 border rounded-lg hover:border-primary/30 transition-all bg-secondary/5 overflow-hidden group">
                                <div className="absolute top-0 left-0 w-full h-2 bg-primary origin-left group-hover:scale-x-105 transition-transform" />
                                <div className="flex flex-col md:flex-row md:items-center gap-4 mt-2">
                                    <div className="flex flex-col items-center justify-center w-16 h-16 bg-white rounded-lg border shadow-sm shrink-0">
                                        <span className="text-xs uppercase font-bold text-muted-foreground">{new Date(booking.date).toLocaleString('default', { month: 'short' })}</span>
                                        <span className="text-xl font-bold text-foreground">{new Date(booking.date).getDate()}</span>
                                    </div>
                                    <div>
                                        <h3 className="font-semibold text-lg">{booking.title}</h3>
                                        <div className="flex flex-wrap items-center gap-3 text-sm text-muted-foreground mt-1">
                                            <span className="flex items-center gap-1 bg-white px-2 py-1 rounded-md border"><Clock className="w-3 h-3" /> {booking.startTime} - {booking.endTime}</span>
                                            <span className="flex items-center gap-1 bg-white px-2 py-1 rounded-md border"><MapPin className="w-3 h-3" /> {booking.room}</span>
                                            <span className="flex items-center gap-1"><User className="w-3 h-3" /> Booked by {booking.bookedBy}</span>
                                        </div>
                                    </div>
                                    <Button 
                                        variant="ghost" 
                                        size="icon" 
                                        className="opacity-0 group-hover:opacity-100 transition-opacity"
                                        onClick={() => openEditBooking(booking)}
                                    >
                                        <Edit2 className="w-4 h-4 text-muted-foreground" />
                                    </Button>
                                </div>
                            </div>
                        ))}
                    </div>
                </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="teachers" className="animate-in fade-in slide-in-from-bottom-2 duration-300">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {teachers.map(teacher => (
                    <Card key={teacher.id} className="border-none shadow-sm hover:shadow-md transition-shadow bg-white overflow-hidden group">
                        <div className="h-2 bg-primary w-full origin-left group-hover:scale-x-105 transition-transform" />
                        <div className="h-24 bg-gradient-to-r from-primary/20 to-secondary/50 relative">
                             <Button 
                                size="icon" 
                                variant="secondary" 
                                className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity bg-white/80 hover:bg-white"
                                onClick={() => openEditTeacher(teacher)}
                             >
                                 <Edit2 className="w-4 h-4" />
                             </Button>
                        </div>
                        <CardContent className="pt-0 -mt-10 text-center pb-6">
                            <div className="flex justify-center mb-4 relative">
                                <Avatar className="w-24 h-24 border-4 border-white shadow-sm bg-white">
                                    <AvatarImage src={teacher.avatarUrl || undefined} className="object-cover" />
                                    <AvatarFallback>{teacher.name.charAt(0)}</AvatarFallback>
                                </Avatar>
                            </div>
                            <h3 className="text-xl font-bold">{teacher.name}</h3>
                            <p className="text-primary font-medium text-sm mb-4">{teacher.role}</p>
                            
                            <div className="space-y-4 text-left">
                                <div>
                                    <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2">Teaches</p>
                                    <div className="flex flex-wrap gap-2 justify-center">
                                        {(teacher.classes || []).map(cls => (
                                            <Badge key={cls} variant="secondary" className="font-normal">{cls}</Badge>
                                        ))}
                                    </div>
                                </div>
                                
                                <div className="flex items-center justify-between border-t pt-4">
                                    <span className="text-sm text-muted-foreground">Solo Availability</span>
                                    {teacher.isAvailableForSolo ? (
                                        <Badge className="bg-green-100 text-green-700 hover:bg-green-100 shadow-none border-none gap-1">
                                            <CheckCircle2 className="w-3 h-3" /> Available
                                        </Badge>
                                    ) : (
                                        <Badge className="bg-gray-100 text-gray-500 hover:bg-gray-100 shadow-none border-none gap-1">
                                            <XCircle className="w-3 h-3" /> Booked
                                        </Badge>
                                    )}
                                </div>

                                {teacher.isAvailableForSolo && (
                                    <Button 
                                        variant="outline" 
                                        className="w-full mt-2" 
                                        onClick={() => {
                                            setSelectedTeacherForSchedule(teacher);
                                            setIsTeacherScheduleOpen(true);
                                        }}
                                    >
                                        <Calendar className="w-4 h-4 mr-2" /> View Schedule
                                    </Button>
                                )}
                            </div>
                        </CardContent>
                    </Card>
                ))}
            </div>
          </TabsContent>
        </Tabs>

        {/* Add Class Modal */}
        <Dialog open={isAddClassOpen} onOpenChange={setIsAddClassOpen}>
            <DialogContent>
                <DialogHeader>
                    <DialogTitle>Add New Class</DialogTitle>
                </DialogHeader>
                <div className="space-y-4 py-4">
                    <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2 col-span-2">
                            <Label>Class Name</Label>
                            <Input value={newClass.name || ""} onChange={e => setNewClass({...newClass, name: e.target.value})} placeholder="e.g. Junior Jazz" />
                        </div>
                        <div className="space-y-2">
                            <Label>Type</Label>
                            <Select value={newClass.type} onValueChange={v => setNewClass({...newClass, type: v as any})}>
                                <SelectTrigger><SelectValue /></SelectTrigger>
                                <SelectContent>
                                    <SelectItem value="Weekly">Weekly Class</SelectItem>
                                    <SelectItem value="Special">Special Event</SelectItem>
                                </SelectContent>
                            </Select>
                        </div>
                        <div className="space-y-2">
                            <Label>Level</Label>
                            <Select value={newClass.level} onValueChange={v => setNewClass({...newClass, level: v})}>
                                <SelectTrigger><SelectValue /></SelectTrigger>
                                <SelectContent>
                                    <SelectItem value="Mini">Mini</SelectItem>
                                    <SelectItem value="Junior">Junior</SelectItem>
                                    <SelectItem value="Teen">Teen</SelectItem>
                                    <SelectItem value="Senior">Senior</SelectItem>
                                    <SelectItem value="All Levels">All Levels</SelectItem>
                                </SelectContent>
                            </Select>
                        </div>
                        <div className="space-y-2">
                            <Label>{newClass.type === "Special" ? "Date" : "Day"}</Label>
                             {newClass.type === "Special" ? (
                                 <Input type="date" value={newClass.day || ""} onChange={e => setNewClass({...newClass, day: e.target.value})} />
                             ) : (
                                <Select value={newClass.day} onValueChange={v => setNewClass({...newClass, day: v})}>
                                    <SelectTrigger><SelectValue /></SelectTrigger>
                                    <SelectContent>
                                        {DAYS.map(d => <SelectItem key={d} value={d}>{d}</SelectItem>)}
                                    </SelectContent>
                                </Select>
                             )}
                        </div>
                        <div className="space-y-2">
                            <Label>Time</Label>
                            <Input type="time" value={newClass.time || ""} onChange={e => setNewClass({...newClass, time: e.target.value})} />
                        </div>
                        <div className="space-y-2 col-span-2">
                            <Label>Teacher</Label>
                            <Select value={newClass.teacherId} onValueChange={v => setNewClass({...newClass, teacherId: v})}>
                                <SelectTrigger><SelectValue /></SelectTrigger>
                                <SelectContent>
                                    {teachers.map(t => <SelectItem key={t.id} value={t.id}>{t.name}</SelectItem>)}
                                </SelectContent>
                            </Select>
                        </div>
                        {newClass.type === "Special" && (
                            <>
                                <div className="space-y-2 col-span-2">
                                    <Label>Description</Label>
                                    <Textarea value={newClass.description || ""} onChange={e => setNewClass({...newClass, description: e.target.value})} placeholder="Event details..." />
                                </div>
                                <div className="space-y-2">
                                    <Label>Cost per Dancer</Label>
                                    <div className="relative">
                                        <DollarSign className="w-4 h-4 absolute left-2 top-2.5 text-muted-foreground" />
                                        <Input type="number" className="pl-8" value={newClass.cost || ""} onChange={e => setNewClass({...newClass, cost: e.target.value})} placeholder="0.00" />
                                    </div>
                                </div>
                            </>
                        )}
                    </div>
                    <Button className="w-full bg-primary text-white" onClick={handleAddClass}>Save Class</Button>
                </div>
            </DialogContent>
        </Dialog>

        {/* Add/Edit Teacher Modal */}
        <Dialog open={isAddTeacherOpen} onOpenChange={setIsAddTeacherOpen}>
            <DialogContent>
                <DialogHeader>
                    <DialogTitle>{editingTeacherId ? "Edit Teacher" : "Add Teacher"}</DialogTitle>
                </DialogHeader>
                <div className="space-y-4 py-4">
                    <div className="flex justify-center mb-4">
                        <Avatar className="w-20 h-20 border-4 border-secondary/20">
                            <AvatarImage src={newTeacher.avatarUrl || undefined} />
                            <AvatarFallback>{newTeacher.name?.charAt(0) || "?"}</AvatarFallback>
                        </Avatar>
                    </div>
                    <div className="space-y-2">
                        <Label>Name</Label>
                        <Input value={newTeacher.name || ""} onChange={e => setNewTeacher({...newTeacher, name: e.target.value})} placeholder="Full Name" />
                    </div>
                    <div className="space-y-2">
                        <Label>Role</Label>
                        <Input value={newTeacher.role || ""} onChange={e => setNewTeacher({...newTeacher, role: e.target.value})} placeholder="e.g. Hip Hop Instructor" />
                    </div>
                    <div className="space-y-2">
                        <Label>Avatar URL</Label>
                        <div className="flex gap-2">
                            <Input value={newTeacher.avatarUrl || ""} onChange={e => setNewTeacher({...newTeacher, avatarUrl: e.target.value})} placeholder="https://..." />
                            <Button variant="outline" size="icon"><Upload className="w-4 h-4" /></Button>
                        </div>
                    </div>
                    <div className="flex items-center gap-4 border p-4 rounded-lg">
                        <Label className="flex-1">Available for Solos/Privates?</Label>
                        <Switch checked={newTeacher.isAvailableForSolo} onCheckedChange={c => setNewTeacher({...newTeacher, isAvailableForSolo: c})} />
                    </div>
                    <Button className="w-full bg-primary text-white" onClick={handleSaveTeacher}>Save Teacher</Button>
                </div>
            </DialogContent>
        </Dialog>

        {/* Add Booking Modal */}
        <Dialog open={isAddBookingOpen} onOpenChange={setIsAddBookingOpen}>
           <DialogContent>
               <DialogHeader>
                   <DialogTitle>{editingBookingId ? "Edit Booking" : "Book Studio"}</DialogTitle>
               </DialogHeader>
               <div className="space-y-4 py-4">
                    <div className="space-y-2">
                        <Label>Title</Label>
                        <Input value={newBooking.title || ""} onChange={e => setNewBooking({...newBooking, title: e.target.value})} placeholder="e.g. Solo Practice" />
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2">
                            <Label>Date</Label>
                            <Input type="date" value={newBooking.date || ""} onChange={e => setNewBooking({...newBooking, date: e.target.value})} />
                        </div>
                        <div className="space-y-2">
                            <Label>Room</Label>
                            <Select value={newBooking.room} onValueChange={v => setNewBooking({...newBooking, room: v})}>
                                <SelectTrigger><SelectValue placeholder="Select Room" /></SelectTrigger>
                                <SelectContent>
                                    <SelectItem value="Studio A">Studio A</SelectItem>
                                    <SelectItem value="Studio B">Studio B</SelectItem>
                                    <SelectItem value="Studio C">Studio C</SelectItem>
                                </SelectContent>
                            </Select>
                        </div>
                        <div className="space-y-2">
                            <Label>Start Time</Label>
                            <Input type="time" value={newBooking.startTime || ""} onChange={e => setNewBooking({...newBooking, startTime: e.target.value})} />
                        </div>
                        <div className="space-y-2">
                            <Label>End Time</Label>
                            <Input type="time" value={newBooking.endTime || ""} onChange={e => setNewBooking({...newBooking, endTime: e.target.value})} />
                        </div>
                    </div>
                    <div className="space-y-2">
                        <Label>Booked By</Label>
                        <Input value={newBooking.bookedBy || ""} onChange={e => setNewBooking({...newBooking, bookedBy: e.target.value})} />
                    </div>
                    <Button className="w-full bg-primary text-white" onClick={handleAddBooking}>Confirm Booking</Button>
                </div>
            </DialogContent>
        </Dialog>

        {/* Teacher Schedule View */}
        <Dialog open={isTeacherScheduleOpen} onOpenChange={setIsTeacherScheduleOpen}>
            <DialogContent className="max-w-2xl">
                <DialogHeader>
                    <DialogTitle>{selectedTeacherForSchedule?.name}'s Availability</DialogTitle>
                </DialogHeader>
                <div className="py-4">
                    <div className="grid grid-cols-6 gap-2 text-center text-sm font-bold text-muted-foreground mb-4">
                        <div className="text-left pl-2">Time</div>
                        {mockWeekDays.map(d => <div key={d}>{d}</div>)}
                    </div>
                    <div className="space-y-2 max-h-[400px] overflow-y-auto">
                        {mockTimeSlots.map(time => (
                            <div key={time} className="grid grid-cols-6 gap-2 items-center">
                                <div className="text-sm font-mono text-muted-foreground pl-2">{time}</div>
                                {mockWeekDays.map(day => (
                                    <div key={`${day}-${time}`} className="h-10 border rounded bg-white hover:border-primary cursor-pointer hover:bg-primary/5 transition-colors flex items-center justify-center">
                                        {/* Fake availability logic */}
                                        {Math.random() > 0.7 ? (
                                            <div className="w-full h-full bg-gray-100 flex items-center justify-center text-[10px] text-gray-400 cursor-not-allowed">Busy</div>
                                        ) : (
                                            <div className="w-2 h-2 rounded-full bg-green-400" />
                                        )}
                                    </div>
                                ))}
                            </div>
                        ))}
                    </div>
                    <div className="mt-4 flex items-center gap-4 text-xs text-muted-foreground">
                        <div className="flex items-center gap-1"><div className="w-2 h-2 rounded-full bg-green-400" /> Available</div>
                        <div className="flex items-center gap-1"><div className="w-4 h-4 bg-gray-100 border rounded" /> Busy</div>
                    </div>
                </div>
            </DialogContent>
        </Dialog>
      </div>
    </Layout>
  );
}
