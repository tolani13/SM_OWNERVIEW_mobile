import { Layout } from "@/components/Layout";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { ScrollArea, ScrollBar } from "@/components/ui/scroll-area";
import { DollarSign, AlertCircle, CheckCircle2, X, Edit2, Plus, Calendar } from "lucide-react";
import { Progress } from "@/components/ui/progress";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { useState, useEffect } from "react";
import { Switch } from "@/components/ui/switch";
import { cn } from "@/lib/utils";
import { useFees, useUpdateFee, useCreateFee, useDancers, useCompetitions, useRoutines, useUpdateRoutine } from "@/hooks/useData";
import type { Fee } from "@shared/schema";

const parseAmount = (amount: string | number | undefined): number => {
    if (typeof amount === 'number') return amount;
    if (typeof amount === 'string') return parseFloat(amount) || 0;
    return 0;
};

const TUITION_RATES: Record<string, number> = {
    "Mini": 120,
    "Junior": 150,
    "Teen": 175,
    "Senior": 200,
    "Elite": 225
};

// Helper to generate months
const MONTHS = [
    "Jan", "Feb", "Mar", "Apr", "May", "Jun", 
    "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
];

// Helper functions
const getDancerName = (dancerId: string | undefined, dancers: any[]) => {
    if (!dancerId) return "Unknown";
    const dancer = dancers.find(d => d.id === dancerId);
    return dancer ? `${dancer.firstName} ${dancer.lastName}` : "Unknown";
};

const getRoutineName = (routineId: string | undefined, routines: any[]) => {
    if (!routineId) return "Unknown";
    const routine = routines.find(r => r.id === routineId);
    return routine ? routine.name : "Unknown";
};

export default function Finance() {
    const { data: fees = [], isLoading: feesLoading } = useFees();
    const { data: dancers = [], isLoading: dancersLoading } = useDancers();
    const { data: competitions = [], isLoading: competitionsLoading } = useCompetitions();
    const { data: routines = [], isLoading: routinesLoading } = useRoutines();
    const updateFee = useUpdateFee();
    const createFee = useCreateFee();
    const updateRoutine = useUpdateRoutine();

    const [selectedCompId, setSelectedCompId] = useState<string | null>(null);
    
    // Tuition State
    const [tuitionRates, setTuitionRates] = useState(TUITION_RATES);
    const [isRateDialogOpen, setIsRateDialogOpen] = useState(false);
    const [rateEffectiveDate, setRateEffectiveDate] = useState(new Date().toISOString().split('T')[0]);

    // Costume Edit State
    const [editingCostumeFee, setEditingCostumeFee] = useState<{feeId: string, costumeName: string, amount: number} | null>(null);

    // Tuition Grid Logic - all hooks must be called unconditionally (before any early returns)
    const [tuitionMatrix, setTuitionMatrix] = useState<Record<string, Record<number, any>>>({});

    // Build tuition matrix from fees and dancers
    useEffect(() => {
        const matrix: Record<string, Record<number, any>> = {};
        
        dancers.forEach(dancer => {
            matrix[dancer.id] = {};
            MONTHS.forEach((_, index) => {
                const existing = fees.find(f => 
                    f.dancerId === dancer.id && 
                    f.type === "Tuition" && 
                    new Date(f.dueDate).getMonth() === index
                );

                if (existing) {
                    matrix[dancer.id][index] = existing;
                } else {
                    matrix[dancer.id][index] = {
                        id: `virt-tuition-${dancer.id}-${index}`,
                        type: "Tuition",
                        amount: tuitionRates[dancer.level] || 0,
                        paid: false,
                        dueDate: new Date(2024, index, 1).toISOString(),
                        dancerId: dancer.id,
                        isVirtual: true
                    };
                }
            });
        });
        setTuitionMatrix(matrix);
    }, [fees, tuitionRates, dancers]);

    const toggleFeePaid = (id: string) => {
        const fee = fees.find(f => f.id === id);
        if (!fee) return;
        updateFee.mutate({ id, data: { paid: !fee.paid } });
    };

    if (feesLoading || dancersLoading || competitionsLoading || routinesLoading) {
        return (
            <Layout>
                <div className="flex items-center justify-center h-64">
                    <div className="text-muted-foreground">Loading...</div>
                </div>
            </Layout>
        );
    }

    const toggleTuitionMonth = (dancerId: string, monthIndex: number) => {
        const fee = tuitionMatrix[dancerId]?.[monthIndex];
        if (!fee) return;

        if (fee.isVirtual) {
            // Create real fee via API
            createFee.mutate({
                type: "Tuition",
                amount: String(fee.amount),
                paid: true,
                dueDate: fee.dueDate,
                dancerId: fee.dancerId
            });
        } else {
            // Toggle existing
            toggleFeePaid(fee.id);
        }
    };

    // Tuition Summary Stats
    const allTuitionFees = Object.values(tuitionMatrix).flatMap(m => Object.values(m));
    const totalTuitionProjected = allTuitionFees.reduce((sum, f) => sum + parseAmount(f.amount), 0);
    const totalTuitionPaid = allTuitionFees.filter(f => f.paid).reduce((sum, f) => sum + parseAmount(f.amount), 0);
    const percentPaid = Math.round((totalTuitionPaid / totalTuitionProjected) * 100) || 0;


    // --- Comp Fees Logic ---
    const compFees = fees.filter(f => f.type === "Competition");
    
    // --- Costume Fees Logic ---
    const costumeFees = fees.filter(f => f.type === "Costume");
    
    const costumeFeesByDancer = dancers.map(dancer => {
        const dFees = costumeFees.filter(f => f.dancerId === dancer.id);
        if (dFees.length === 0) return null;
        
        const total = dFees.reduce((sum, f) => sum + parseAmount(f.amount), 0);
        const paid = dFees.filter(f => f.paid).reduce((sum, f) => sum + parseAmount(f.amount), 0);
        const unpaid = total - paid;
        
        return {
            dancer,
            fees: dFees,
            total,
            paid,
            unpaid
        };
    }).filter(Boolean);

    const selectedComp = competitions.find(c => c.id === selectedCompId);
    const selectedCompEntries = compFees.filter(f => f.competitionId === selectedCompId);
    const compTotal = selectedCompEntries.reduce((s, f) => s + parseAmount(f.amount), 0);
    const compPaid = selectedCompEntries.filter(f => f.paid).reduce((s, f) => s + parseAmount(f.amount), 0);
    const compUnpaid = compTotal - compPaid;

    const handleSaveCostume = () => {
        if (!editingCostumeFee) return;
        
        // Update fee amount via API
        updateFee.mutate({ id: editingCostumeFee.feeId, data: { amount: String(editingCostumeFee.amount) } });
        
        // Update routine costume name (find routine from fee)
        const fee = fees.find(f => f.id === editingCostumeFee.feeId);
        if (fee && fee.routineId) {
            updateRoutine.mutate({ id: fee.routineId, data: { costumeName: editingCostumeFee.costumeName } });
        }
        
        setEditingCostumeFee(null);
    };

    return (
        <Layout>
            <div className="space-y-6">
                <div>
                    <h1 className="text-3xl font-display font-bold">Finance</h1>
                    <p className="text-muted-foreground">Track studio tuition, costumes, and competition fees.</p>
                </div>

                <Tabs defaultValue="studio" className="w-full">
                    <TabsList className="bg-white/50 border p-1 h-auto mb-6">
                        <TabsTrigger value="studio" className="py-2 px-6 rounded-md data-[state=active]:bg-[#FF9F7F] data-[state=active]:text-white data-[state=active]:shadow-sm transition-colors">Tuition</TabsTrigger>
                        <TabsTrigger value="competitions" className="py-2 px-6 rounded-md data-[state=active]:bg-[#FF9F7F] data-[state=active]:text-white data-[state=active]:shadow-sm transition-colors">Comp Fees</TabsTrigger>
                        <TabsTrigger value="costumes" className="py-2 px-6 rounded-md data-[state=active]:bg-[#FF9F7F] data-[state=active]:text-white data-[state=active]:shadow-sm transition-colors">Costumes</TabsTrigger>
                    </TabsList>

                    {/* STUDIO FEES (TUITION) TAB */}
                    <TabsContent value="studio" className="animate-in fade-in slide-in-from-bottom-2">
                        <div className="grid md:grid-cols-3 gap-6 mb-8">
                            <Card className="bg-primary text-white border-none shadow-md group overflow-hidden">
                                <div className="h-2 bg-white/20 w-full origin-left group-hover:scale-x-105 transition-transform" />
                                <CardContent className="p-6">
                                    <p className="opacity-90 text-sm font-medium mb-1">Annual Tuition Projected</p>
                                    <h3 className="text-3xl font-bold">${totalTuitionProjected.toLocaleString()}</h3>
                                    <div className="mt-4">
                                        <div className="flex justify-between text-xs mb-1 opacity-90">
                                            <span>Collected YTD</span>
                                            <span>{percentPaid}%</span>
                                        </div>
                                        <Progress value={percentPaid} className="h-2 bg-white/30" indicatorClassName="bg-white" />
                                    </div>
                                </CardContent>
                            </Card>
                            
                            <Card className="col-span-2 border-none shadow-sm bg-white relative overflow-hidden group">
                                <div className="h-2 bg-primary w-full origin-left group-hover:scale-x-105 transition-transform" />
                                <CardHeader className="pb-2 flex flex-row items-center justify-between">
                                    <CardTitle className="text-base">Current Monthly Rates</CardTitle>
                                    <Button variant="outline" size="sm" onClick={() => setIsRateDialogOpen(true)}>
                                        <Edit2 className="w-3 h-3 mr-2" /> Manage Rates
                                    </Button>
                                </CardHeader>
                                <CardContent>
                                    <div className="flex flex-wrap gap-4">
                                        {Object.entries(tuitionRates).map(([level, rate]) => (
                                            <div key={level} className="flex flex-col items-center p-3 bg-secondary/10 rounded-lg min-w-[80px]">
                                                <span className="text-xs font-bold uppercase text-muted-foreground">{level}</span>
                                                <span className="font-bold text-lg">${rate}</span>
                                            </div>
                                        ))}
                                    </div>
                                    <div className="text-xs text-muted-foreground mt-4 text-right">
                                        Effective as of: {new Date(rateEffectiveDate).toLocaleDateString()}
                                    </div>
                                </CardContent>
                            </Card>
                        </div>

                        <Card className="border-none shadow-sm bg-white overflow-hidden group">
                            <div className="h-2 bg-primary w-full origin-left group-hover:scale-x-105 transition-transform" />
                            <CardHeader className="pb-4">
                                <div className="flex justify-between items-center">
                                    <CardTitle>Tuition Tracker (Jan - Dec)</CardTitle>
                                    <div className="flex items-center gap-2 text-sm text-muted-foreground">
                                        <span className="flex items-center gap-1"><div className="w-3 h-3 rounded-full bg-green-500"/> Paid</span>
                                        <span className="flex items-center gap-1"><div className="w-3 h-3 rounded-full bg-gray-200"/> Unpaid</span>
                                    </div>
                                </div>
                            </CardHeader>
                            <CardContent className="p-0">
                                <ScrollArea className="w-full whitespace-nowrap">
                                    <div className="min-w-[1000px]">
                                        <Table>
                                            <TableHeader>
                                                <TableRow className="hover:bg-transparent">
                                                    <TableHead className="w-[200px] sticky left-0 bg-white z-10 font-bold text-foreground">Dancer</TableHead>
                                                    <TableHead className="w-[100px] text-center bg-gray-50/50">Rate</TableHead>
                                                    {MONTHS.map(m => (
                                                        <TableHead key={m} className="text-center w-[80px] text-xs uppercase font-bold text-muted-foreground">{m}</TableHead>
                                                    ))}
                                                </TableRow>
                                            </TableHeader>
                                            <TableBody>
                                                {dancers.map(dancer => (
                                                    <TableRow key={dancer.id} className="hover:bg-gray-50/50">
                                                        <TableCell className="font-medium sticky left-0 bg-white z-10 shadow-[2px_0_5px_-2px_rgba(0,0,0,0.1)]">
                                                            {dancer.firstName} {dancer.lastName.charAt(0)}.
                                                            <div className="text-[10px] text-muted-foreground uppercase">{dancer.level}</div>
                                                        </TableCell>
                                                        <TableCell className="text-center text-muted-foreground font-mono bg-gray-50/30">
                                                            ${tuitionRates[dancer.level]}
                                                        </TableCell>
                                                        {MONTHS.map((_, index) => {
                                                            const fee = tuitionMatrix[dancer.id]?.[index];
                                                            return (
                                                                <TableCell key={index} className="text-center p-2">
                                                                    <div className="flex justify-center">
                                                                        <Switch 
                                                                            checked={fee?.paid} 
                                                                            onCheckedChange={() => toggleTuitionMonth(dancer.id, index)}
                                                                            className="data-[state=checked]:bg-green-500 scale-75" 
                                                                        />
                                                                    </div>
                                                                </TableCell>
                                                            );
                                                        })}
                                                    </TableRow>
                                                ))}
                                            </TableBody>
                                        </Table>
                                    </div>
                                    <ScrollBar orientation="horizontal" />
                                </ScrollArea>
                            </CardContent>
                        </Card>
                    </TabsContent>

                    {/* COMP FEES TAB */}
                    <TabsContent value="competitions" className="animate-in fade-in slide-in-from-bottom-2">
                        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                            {competitions.map(comp => {
                                const feesForComp = compFees.filter(f => f.competitionId === comp.id);
                                if (feesForComp.length === 0) return null;

                                const total = feesForComp.reduce((sum, f) => sum + parseAmount(f.amount), 0);
                                const paid = feesForComp.filter(f => f.paid).reduce((sum, f) => sum + parseAmount(f.amount), 0);
                                
                                return (
                                    <Card key={comp.id} className="border-none shadow-sm bg-white overflow-hidden cursor-pointer hover:shadow-md transition-shadow group" onClick={() => setSelectedCompId(comp.id)}>
                                        <div className="h-2 bg-blue-500 w-full group-hover:h-3 transition-all" />
                                        <CardHeader className="pb-2">
                                            <CardTitle className="text-lg">{comp.name}</CardTitle>
                                            <CardDescription>{new Date(comp.startDate).toLocaleDateString()}</CardDescription>
                                        </CardHeader>
                                        <CardContent>
                                            <div className="space-y-2 mt-2">
                                                <div className="flex justify-between items-center text-sm">
                                                    <span className="text-muted-foreground">Total</span>
                                                    <span className="font-bold text-blue-700">${total.toFixed(2)}</span>
                                                </div>
                                                <div className="flex justify-between items-center text-sm">
                                                    <span className="text-muted-foreground">Paid</span>
                                                    <span className="text-green-600 font-medium">${paid.toFixed(2)}</span>
                                                </div>
                                                <div className="pt-2 border-t text-[10px] text-muted-foreground text-center">
                                                    {feesForComp.length} fee entries linked
                                                </div>
                                            </div>
                                        </CardContent>
                                    </Card>
                                )
                            })}
                        </div>
                    </TabsContent>

                    {/* COSTUMES TAB */}
                    <TabsContent value="costumes" className="animate-in fade-in slide-in-from-bottom-2">
                        <div className="grid gap-6">
                            {costumeFeesByDancer.map((group) => (
                                <Card key={group?.dancer.id} className="border-none shadow-sm bg-white border-l-4 border-l-pink-400 group overflow-hidden">
                                    <div className="h-2 bg-primary w-full origin-left group-hover:scale-x-105 transition-transform" />
                                    <CardHeader className="bg-secondary/10 pb-4 border-b border-gray-100">
                                        <div className="flex justify-between items-center">
                                            <div className="flex items-center gap-3">
                                                <div className="w-10 h-10 rounded-full bg-white border flex items-center justify-center font-bold text-pink-500">
                                                    {group?.dancer.firstName.charAt(0)}
                                                </div>
                                                <div>
                                                    <CardTitle className="text-lg">{group?.dancer.firstName} {group?.dancer.lastName}</CardTitle>
                                                    <CardDescription>{group?.dancer.level}</CardDescription>
                                                </div>
                                            </div>
                                            <div className="text-right">
                                                <p className="text-sm text-muted-foreground">Total Due</p>
                                                <p className="font-bold text-lg text-pink-600">${group?.total?.toFixed(2)}</p>
                                            </div>
                                        </div>
                                    </CardHeader>
                                    <CardContent className="p-0">
                                        <div className="divide-y divide-gray-100">
                                            {group?.fees.map(fee => {
                                                // Find the routine to get the costume name
                                                const routine = routines.find(r => r.id === fee.routineId);
                                                
                                                return (
                                                    <div key={fee.id} className="flex items-center justify-between p-4 hover:bg-gray-50 group">
                                                        <div className="flex items-center gap-4">
                                                            {fee.paid ? (
                                                                <CheckCircle2 className="w-5 h-5 text-green-500 shrink-0" />
                                                            ) : (
                                                                <AlertCircle className="w-5 h-5 text-red-400 shrink-0" />
                                                            )}
                                                            <div>
                                                                <div className="flex items-center gap-2">
                                                                    <p className="font-medium text-sm">{routine?.name || "Unknown Routine"}</p>
                                                                    <Badge variant="outline" className="text-[10px] h-5 px-1 bg-pink-50 text-pink-700 border-pink-100">
                                                                        {routine?.costumeName || "No Costume Name"}
                                                                    </Badge>
                                                                </div>
                                                                <p className="text-xs text-muted-foreground">Routine: {routine?.type} {routine?.style}</p>
                                                            </div>
                                                        </div>
                                                        <div className="flex items-center gap-4">
                                                            <div className="text-right mr-2">
                                                                <span className="text-sm font-semibold block">${fee.amount}</span>
                                                                <button 
                                                                    onClick={() => setEditingCostumeFee({
                                                                        feeId: fee.id,
                                                                        costumeName: routine?.costumeName || "",
                                                                        amount: parseAmount(fee.amount)
                                                                    })}
                                                                    className="text-[10px] text-blue-500 hover:text-blue-700 opacity-0 group-hover:opacity-100 transition-opacity flex items-center gap-1 justify-end ml-auto"
                                                                >
                                                                    <Edit2 className="w-3 h-3" /> Edit
                                                                </button>
                                                            </div>
                                                            <Switch 
                                                                checked={fee.paid} 
                                                                onCheckedChange={() => toggleFeePaid(fee.id)}
                                                                className="data-[state=checked]:bg-green-500" 
                                                            />
                                                        </div>
                                                    </div>
                                                );
                                            })}
                                        </div>
                                        {group?.unpaid! > 0 && (
                                            <div className="bg-red-50 p-3 text-center border-t border-red-100 text-red-700 text-sm font-medium">
                                                Outstanding Balance: ${group?.unpaid?.toFixed(2)}
                                            </div>
                                        )}
                                    </CardContent>
                                </Card>
                            ))}
                        </div>
                    </TabsContent>
                </Tabs>

                {/* Competition Fee Modal */}
                <Dialog open={!!selectedCompId} onOpenChange={(open) => !open && setSelectedCompId(null)}>
                    <DialogContent className="max-w-2xl p-0 overflow-hidden border-none shadow-2xl rounded-2xl">
                        {selectedComp && (
                            <div className="bg-[#FAF9F6]">
                                {/* Header */}
                                <div className="p-8 pb-6 border-b border-gray-100">
                                    <div className="flex justify-between items-start mb-4">
                                        <div>
                                            <h2 className="text-2xl font-display font-bold text-foreground border-b-2 border-blue-500/50 inline-block">
                                                {selectedComp.name}
                                            </h2>
                                            <p className="text-sm text-muted-foreground mt-2">
                                                {new Date(selectedComp.startDate).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })} • {selectedComp.location}
                                            </p>
                                        </div>
                                        <button onClick={() => setSelectedCompId(null)} className="p-2 hover:bg-gray-100 rounded-full transition-colors">
                                            <X className="w-5 h-5 text-muted-foreground" />
                                        </button>
                                    </div>

                                    {/* Summary Row */}
                                    <div className="grid grid-cols-3 gap-4 mt-8">
                                        <div className="bg-white p-4 rounded-xl text-center shadow-sm border border-gray-50">
                                            <p className="text-[10px] uppercase tracking-wider font-bold text-muted-foreground mb-1">Total Fees</p>
                                            <p className="text-xl font-bold">${compTotal.toFixed(2)}</p>
                                        </div>
                                        <div className="bg-white p-4 rounded-xl text-center shadow-sm border border-gray-50">
                                            <p className="text-[10px] uppercase tracking-wider font-bold text-green-600 mb-1">Collected</p>
                                            <p className="text-xl font-bold text-green-600">${compPaid.toFixed(2)}</p>
                                        </div>
                                        <div className="bg-white p-4 rounded-xl text-center shadow-sm border border-gray-50">
                                            <p className="text-[10px] uppercase tracking-wider font-bold text-red-600 mb-1">Outstanding</p>
                                            <p className="text-xl font-bold text-red-600">${compUnpaid.toFixed(2)}</p>
                                        </div>
                                    </div>
                                </div>

                                {/* Entries Table */}
                                <div className="p-8 pt-4">
                                    <div className="grid grid-cols-12 text-[10px] uppercase tracking-wider font-bold text-muted-foreground pb-4 px-4">
                                        <div className="col-span-6">Dancer / Routine</div>
                                        <div className="col-span-2 text-center">Fee Type</div>
                                        <div className="col-span-2 text-center">Amount</div>
                                        <div className="col-span-2 text-right">Paid</div>
                                    </div>
                                    <div className="space-y-1">
                                        {selectedCompEntries.map(fee => (
                                            <div key={fee.id} className="grid grid-cols-12 items-center p-4 bg-white rounded-xl shadow-sm border border-gray-50 hover:border-blue-500/20 transition-all">
                                                <div className="col-span-6 flex items-center gap-3">
                                                    <div className="w-8 h-8 rounded-full bg-blue-50 flex items-center justify-center text-blue-600">
                                                        <DollarSign className="w-4 h-4" />
                                                    </div>
                                                    <div>
                                                        <p className="font-semibold text-sm">{getDancerName(fee.dancerId, dancers)}</p>
                                                        {fee.routineId && <p className="text-[10px] text-muted-foreground">Routine: {getRoutineName(fee.routineId, routines)}</p>}
                                                    </div>
                                                </div>
                                                <div className="col-span-2 text-center text-xs font-medium text-muted-foreground">
                                                    {fee.routineId ? "Routine" : "Entry"}
                                                </div>
                                                <div className="col-span-2 text-center font-bold text-sm">
                                                    ${parseAmount(fee.amount).toFixed(2)}
                                                </div>
                                                <div className="col-span-2 flex justify-end">
                                                    <Switch 
                                                        checked={fee.paid} 
                                                        onCheckedChange={() => toggleFeePaid(fee.id)}
                                                        className="data-[state=checked]:bg-green-500" 
                                                    />
                                                </div>
                                            </div>
                                        ))}
                                    </div>
                                </div>
                            </div>
                        )}
                    </DialogContent>
                </Dialog>

                {/* Edit Costume Dialog */}
                <Dialog open={!!editingCostumeFee} onOpenChange={(open) => !open && setEditingCostumeFee(null)}>
                    <DialogContent className="sm:max-w-[425px]">
                        <DialogHeader>
                            <DialogTitle>Edit Costume Details</DialogTitle>
                        </DialogHeader>
                        {editingCostumeFee && (
                            <div className="grid gap-4 py-4">
                                <div className="grid grid-cols-4 items-center gap-4">
                                    <Label htmlFor="costumeName" className="text-right">
                                        Costume Name
                                    </Label>
                                    <Input
                                        id="costumeName"
                                        value={editingCostumeFee.costumeName}
                                        onChange={(e) => setEditingCostumeFee({ ...editingCostumeFee, costumeName: e.target.value })}
                                        className="col-span-3"
                                    />
                                </div>
                                <div className="grid grid-cols-4 items-center gap-4">
                                    <Label htmlFor="amount" className="text-right">
                                        Fee Amount
                                    </Label>
                                    <Input
                                        id="amount"
                                        type="number"
                                        value={editingCostumeFee.amount}
                                        onChange={(e) => setEditingCostumeFee({ ...editingCostumeFee, amount: parseFloat(e.target.value) })}
                                        className="col-span-3"
                                    />
                                </div>
                            </div>
                        )}
                        <DialogFooter>
                            <Button type="submit" onClick={handleSaveCostume}>Save changes</Button>
                        </DialogFooter>
                    </DialogContent>
                </Dialog>

                {/* Manage Tuition Rates Dialog */}
                <Dialog open={isRateDialogOpen} onOpenChange={setIsRateDialogOpen}>
                    <DialogContent className="sm:max-w-[425px]">
                        <DialogHeader>
                            <DialogTitle>Manage Tuition Rates</DialogTitle>
                        </DialogHeader>
                        <div className="grid gap-4 py-4">
                            <div className="flex flex-col gap-2 mb-4">
                                <Label htmlFor="effectiveDate">Rates Effective As Of</Label>
                                <div className="flex items-center gap-2">
                                    <Calendar className="w-4 h-4 text-muted-foreground" />
                                    <Input 
                                        id="effectiveDate" 
                                        type="date" 
                                        value={rateEffectiveDate}
                                        onChange={(e) => setRateEffectiveDate(e.target.value)}
                                    />
                                </div>
                            </div>

                            {Object.entries(tuitionRates).map(([level, rate]) => (
                                <div key={level} className="grid grid-cols-4 items-center gap-4">
                                    <Label htmlFor={`rate-${level}`} className="text-right capitalize">
                                        {level}
                                    </Label>
                                    <div className="col-span-3 relative">
                                        <DollarSign className="w-4 h-4 absolute left-2.5 top-2.5 text-muted-foreground" />
                                        <Input
                                            id={`rate-${level}`}
                                            type="number"
                                            value={rate}
                                            onChange={(e) => setTuitionRates({ ...tuitionRates, [level]: parseInt(e.target.value) || 0 })}
                                            className="pl-8"
                                        />
                                    </div>
                                </div>
                            ))}
                        </div>
                        <DialogFooter>
                            <Button type="submit" onClick={() => setIsRateDialogOpen(false)}>Update Rates</Button>
                        </DialogFooter>
                    </DialogContent>
                </Dialog>
            </div>
        </Layout>
    )
}
