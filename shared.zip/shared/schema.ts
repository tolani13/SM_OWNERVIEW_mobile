import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, boolean, date, timestamp, decimal } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Dancers table
export const dancers = pgTable("dancers", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  firstName: text("first_name").notNull(),
  lastName: text("last_name").notNull(),
  age: integer("age").notNull(),
  level: text("level").notNull(), // Mini, Junior, Teen, Senior, Elite
  status: text("status").notNull().default('Active'), // Active, Inactive
  email: text("email"),
  parentName: text("parent_name"),
  parentPhone: text("parent_phone"),
  parentEmail: text("parent_email"),
  emergencyContact: text("emergency_contact"),
  studioNotes: text("studio_notes"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertDancerSchema = createInsertSchema(dancers).omit({
  id: true,
  createdAt: true,
});

export type InsertDancer = z.infer<typeof insertDancerSchema>;
export type Dancer = typeof dancers.$inferSelect;

// Teachers table
export const teachers = pgTable("teachers", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  role: text("role").notNull(),
  avatarUrl: text("avatar_url"),
  classes: text("classes").array(), // Array of class names
  isAvailableForSolo: boolean("is_available_for_solo").notNull().default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertTeacherSchema = createInsertSchema(teachers).omit({
  id: true,
  createdAt: true,
});

export type InsertTeacher = z.infer<typeof insertTeacherSchema>;
export type Teacher = typeof teachers.$inferSelect;

// Routines table
export const routines = pgTable("routines", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  style: text("style").notNull(), // Jazz, Lyrical, Contemporary, Tap, Hip Hop, Ballet, Open
  type: text("type").notNull(), // Solo, Duet, Trio, Small Group, Large Group, Line, Production
  dancerIds: text("dancer_ids").array().notNull(), // Array of dancer IDs
  paidDancerIds: text("paid_dancer_ids").array().default(sql`ARRAY[]::text[]`), // Array of dancer IDs who paid
  costumeFee: decimal("costume_fee", { precision: 10, scale: 2 }).notNull(),
  costumeName: text("costume_name"),
  costumePaid: boolean("costume_paid").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertRoutineSchema = createInsertSchema(routines).omit({
  id: true,
  createdAt: true,
});

export type InsertRoutine = z.infer<typeof insertRoutineSchema>;
export type Routine = typeof routines.$inferSelect;

// Competitions table
export const competitions = pgTable("competitions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  location: text("location").notNull(),
  startDate: date("start_date").notNull(),
  endDate: date("end_date").notNull(),
  status: text("status").notNull().default('Upcoming'), // Upcoming, Completed
  logoUrl: text("logo_url"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertCompetitionSchema = createInsertSchema(competitions).omit({
  id: true,
  createdAt: true,
});

export type InsertCompetition = z.infer<typeof insertCompetitionSchema>;
export type Competition = typeof competitions.$inferSelect;

// Run Slots table
export const runSlots = pgTable("run_slots", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  competitionId: varchar("competition_id").notNull(),
  routineId: varchar("routine_id"),
  day: text("day").notNull(),
  time: text("time").notNull(),
  stage: text("stage").notNull(),
  orderNumber: integer("order_number").notNull(),
  category: text("category").notNull(),
  notes: text("notes").default(''),
  placement: text("placement"),
  specialAward: text("special_award"),
  isStudioRoutine: boolean("is_studio_routine").default(false),
  studio: text("studio"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertRunSlotSchema = createInsertSchema(runSlots).omit({
  id: true,
  createdAt: true,
});

export type InsertRunSlot = z.infer<typeof insertRunSlotSchema>;
export type RunSlot = typeof runSlots.$inferSelect;

// Convention Classes table
export const conventionClasses = pgTable("convention_classes", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  competitionId: varchar("competition_id").notNull(),
  day: text("day").notNull(),
  time: text("time").notNull(),
  name: text("name").notNull(),
  teacher: text("teacher").notNull(),
  room: text("room").notNull(),
  level: text("level").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertConventionClassSchema = createInsertSchema(conventionClasses).omit({
  id: true,
  createdAt: true,
});

export type InsertConventionClass = z.infer<typeof insertConventionClassSchema>;
export type ConventionClass = typeof conventionClasses.$inferSelect;

// Studio Classes table
export const studioClasses = pgTable("studio_classes", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  day: text("day").notNull(),
  time: text("time").notNull(),
  teacherId: varchar("teacher_id").notNull(),
  level: text("level").notNull(),
  type: text("type").notNull(), // Weekly, Special
  description: text("description"),
  cost: decimal("cost", { precision: 10, scale: 2 }),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertStudioClassSchema = createInsertSchema(studioClasses).omit({
  id: true,
  createdAt: true,
});

export type InsertStudioClass = z.infer<typeof insertStudioClassSchema>;
export type StudioClass = typeof studioClasses.$inferSelect;

// Practice Bookings table
export const practiceBookings = pgTable("practice_bookings", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  title: text("title").notNull(),
  date: date("date").notNull(),
  startTime: text("start_time").notNull(),
  endTime: text("end_time").notNull(),
  room: text("room").notNull(),
  bookedBy: text("booked_by").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertPracticeBookingSchema = createInsertSchema(practiceBookings).omit({
  id: true,
  createdAt: true,
});

export type InsertPracticeBooking = z.infer<typeof insertPracticeBookingSchema>;
export type PracticeBooking = typeof practiceBookings.$inferSelect;

// Announcements table
export const announcements = pgTable("announcements", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  title: text("title").notNull(),
  content: text("content").notNull(),
  date: text("date").notNull(), // Store as ISO string for simplicity
  tags: text("tags").array().notNull(), // Studio, Competition, Level
  status: text("status").notNull().default('Active'), // Active, Archived
  isPinned: boolean("is_pinned").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertAnnouncementSchema = createInsertSchema(announcements).omit({
  id: true,
  createdAt: true,
});

export type InsertAnnouncement = z.infer<typeof insertAnnouncementSchema>;
export type Announcement = typeof announcements.$inferSelect;

// Fees table
export const fees = pgTable("fees", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  type: text("type").notNull(), // Tuition, Competition, Costume
  amount: decimal("amount", { precision: 10, scale: 2 }).notNull(),
  paid: boolean("paid").notNull().default(false),
  dueDate: date("due_date").notNull(),
  dancerId: varchar("dancer_id").notNull(),
  competitionId: varchar("competition_id"),
  routineId: varchar("routine_id"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertFeeSchema = createInsertSchema(fees).omit({
  id: true,
  createdAt: true,
});

export type InsertFee = z.infer<typeof insertFeeSchema>;
export type Fee = typeof fees.$inferSelect;
